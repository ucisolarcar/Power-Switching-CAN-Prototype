/* Authored by: Julius Yang

- v0.1 3/29/24 - Just writing the header file for functions I think we need

*/

//Header file for a library to handle transmitting/receiving data from sensors via CANbus

#ifndef SENSOR_FUNCTS
#define SENSOR_FUNCTS

//standard header file to include for Arduino
#include <Arduino.h>

//Header files to include
#include <SPI.h>              //Library for using SPI Communication 
#include <mcp2515.h>          //Library for using CAN Communication (https://github.com/autowp/arduino-mcp2515/)
#include <Adafruit_GPS.h>
#include "canFloat.h"

/*
******************************************************************************************************************
Structs:
*/

//Defining float array struct for accelerometers:
typedef struct accelDataArr
{
  float arr[3];
};

//Defining int array struct for 1 decimal point for decimal breakdown
//Have it set to a max of 6 for now
typedef struct decData
{
  uint8_t arr[7] = {0};
};

/*
******************************************************************************************************************
Defining the SensorFunctions Class:
*/
class SensorFunctions {

  //mainly private functions here that are used in the public functions
  //I don't think there is a need for any private variables
  private: 
    //Global Private Functions
    decData decimal_breakdown(float value, int decimalpoint);

    float canToOneFloat(__u8 data[8], int startI, int endI);

    //Private Accelerometer Functions
    float getAccelX(int xpin);
    float getAccelY(int ypin);
    float getAccelZ(int zpin);
    accelDataArr getAccel(int xpin, int ypin, int zpin);

    //Private Current Function
    float getCurrentData(int pin, float offset);

    //Private GPS Function:
    float ToDecimalDegrees(float formattedLatLon, char cardinal);
  
  public:
    //constructor:
    SensorFunctions();

    //functions to transmit data from different sensors:

    //transmit Accel takes in the pins for the accelerometer along with the can id that it should transmit to
    bool transmitAccel(MCP2515 mcp2515, struct can_frame canMsg, canid_t id, int xpin, int ypin, int zpin, bool debug);

    //transmitCurr takes in the can ID that it should be transmitting and the current sensor's pin number
    bool transmitCurr(MCP2515 mcp2515, struct can_frame canMsg, canid_t id, int currPin, float offset, bool debug);

    bool transmitGPS(MCP2515 mcp2515, Adafruit_GPS GPS, struct can_frame canMsg, canid_t id, bool debug);

    //calibrateCurr takes in the current sensor's pin number and calibrates the sensor
    float calibrateCurr(int currpin);

    //hoping this code can just help to simplify the setup of the GPS
    //returns a Adafruit_GPS so that it hopefully can be used by the rest of the program
    Adafruit_GPS gpsSetup(HardwareSerial *serialPtr);

    //functions to parse data, separated by sensor type:
    //UNTESTED!


    accelDataArr parseAccel(can_frame msg, bool debug);

    float parseCurrent(can_frame msg, bool debug);

    floatPair parseGPS(can_frame msg, bool debug);
};

#endif