#include "sensorFunctions.h"

//Create a SensorFunctions:
SensorFunctions::SensorFunctions()
{
}

/*
******************************************************************************************************************
"Global" Private Functions:
******************************************************************************************************************
*/

//breakdown floating points to a specific decimal point (UP TO 6 DECIMAL POINTS!!)
decData SensorFunctions::decimal_breakdown(float value, int decimalpoint) {
  //I use a struct to make it easier to send data
  struct decData output;
  output.arr[0] = int(value);
  
  for (int i = 0; i < decimalpoint; i++) {
    value = value - int(value);
    value = value * 10;
    output.arr[i + 1] = int(value);
  }
  return output;
}

//NEED this for now, might not need this with the inclusion of the library
//function to convert array elements into a float value:
float SensorFunctions::canToOneFloat(__u8 data[8], int startI, int endI)
{
  int8_t intArr[8];
  //first convert each unsigned char into a signed int of 8 bits:
  for(int i = 0; i < 8; i++)
  {
    intArr[i] = (int8_t) data[i];
  }

  //then do funny stuff
  bool negFlag = false; //flag to indicate if the number should be negative or not
  float output = 0.0;
  float multNum = 1; //float that will be multiplied by .1 for decimal places
  for(int i = startI; i <= endI; i++)
  {
    if(intArr[i] < 0 && negFlag == false)
      negFlag = true; //set the flag to true if one of the values is negative
    output += abs(multNum * intArr[i]);
    multNum *= 0.1;
  }
  if(negFlag) //if one of the array values is negative make the whole thing negative
    output *= -1;
  return output;
}

/*
******************************************************************************************************************
Accelerometer Private Functions:
*/


//WARNING, this is using predetermined data for calibration, might need to have a way to calibrate the accelerometers
// Modular code to get data from accelerometer 1 or 2 based on id:
float SensorFunctions::getAccelX(int xpin)
{
  //get X axis values
  int xvalue = analogRead(xpin);
  int x = map(xvalue, 401, 507, -100, 100);
  float xg = (float)x/(-100.00);
  return xg;
}

float SensorFunctions::getAccelY(int ypin)
{
  //get Y axis values
  int yvalue = analogRead(ypin);
  int y = map(yvalue, 269, 402, -100, 100);
  float yg = (float)y/(-100.00);
  return yg;
  
}

float SensorFunctions::getAccelZ(int zpin)
{
  //get Z axis values
  int zvalue = analogRead(zpin);
  int z = map(zvalue, 274, 407, -100, 100);
  float zg = (float)z/(-100.00);
  return zg;
}

//this will fetch data from the accelerometer and returns a struct that contains the G-force values of each axis
accelDataArr SensorFunctions::getAccel(int xpin, int ypin, int zpin)
{
  accelDataArr accelData;
  accelData.arr[0] = getAccelX(xpin);
  accelData.arr[1] = getAccelY(ypin);
  accelData.arr[2] = getAccelZ(zpin);
  return accelData;
}

/*
******************************************************************************************************************
Current Sensor Private Functions:
*/

float SensorFunctions::getCurrentData(int pin, float offset)
{
  float rawReading = 0.0;
  for(int i = 0; i < 150; i++)
  {
    rawReading += analogRead(pin);
    //delay(3);
  }

  float avg = (rawReading / 150) - offset;
  float voltage = (avg / 1024.0) * 5000; //mV
  float amps = ((voltage) / 100);
  return amps;
}

/*
******************************************************************************************************************
GPS Private Function:
*/

float SensorFunctions::ToDecimalDegrees(float formattedLatLon, char cardinal)
{
  int sign = 1;
  if(cardinal == 'W' || cardinal == 'S')
    sign = -1;
  float decDegrees = (float)((int)formattedLatLon / 100);
  float decMinutes = formattedLatLon - (decDegrees * 100);
  float fractDegrees = decMinutes / 60.0;
  
  return sign * (decDegrees + fractDegrees);
}


/*
******************************************************************************************************************
Public Transmit Functions:
******************************************************************************************************************
*/

//comments about this function goes here
bool SensorFunctions::transmitAccel(MCP2515 mcp2515, struct can_frame canMsg, canid_t id, int xpin, int ypin, int zpin, bool debug)
{
  canMsg.can_id  = id;
  canMsg.can_dlc = 8;  //CAN data array length
  //Important thing to note, CAN data can be max 8 index long
  //get data from Accelerometer
  accelDataArr accelData;
  accelData = getAccel(xpin, ypin, zpin);

  float x = accelData.arr[0];
  float y = accelData.arr[1];
  float z = accelData.arr[2];

  //convert data gathered into a form that can be transmitted using a struct defined earlier
  struct decData xArr = decimal_breakdown(x, 1);
  struct decData yArr = decimal_breakdown(y, 1);
  struct decData zArr = decimal_breakdown(z, 1);

  //indicating data is coming from the accelerometer
  //First data byte doesn't need to be ID anymore!!
  canMsg.data[0] = 0;
  canMsg.data[1] = xArr.arr[0]; //getting whole number for x value
  canMsg.data[2] = xArr.arr[1]; //then the 1st decimal point for the x value
  canMsg.data[3] = yArr.arr[0];
  canMsg.data[4] = yArr.arr[1];
  canMsg.data[5] = zArr.arr[0];
  canMsg.data[6] = zArr.arr[1];
  canMsg.data[7] = 0;
  //NEW EX data: 0|x1|x2|y1|y2|z1|z2|0

  //if debug is on then print out what values are sent
  if(debug)
  {
    Serial.print("Sent Accelerometer 1 with x: ");
    Serial.print(x);
    Serial.print("\ty: ");
    Serial.print(y);
    Serial.print("\tz: ");
    Serial.println(z);
  }

  if(mcp2515.sendMessage(&canMsg) == 0) //Sends the CAN message
    return true;  //if successful
  else
    return false; //if failed
}

//function description here
bool SensorFunctions::transmitCurr(MCP2515 mcp2515, struct can_frame canMsg, canid_t id, int currPin, float offset, bool debug)
{
  canMsg.can_id  = id;
  canMsg.can_dlc = 8;  //CAN data array length
  //Important thing to note, CAN data can be max 8 index long

  //get Data from current sensor:
  float current = getCurrentData(currPin, offset);

  //Test with canFloats
  CanFloats currData = CanFloats(current, 0);
  CAN currCAN = currData.getCAN();

  canMsg.data[0] = currCAN.byte1;
  canMsg.data[1] = currCAN.byte2;
  canMsg.data[2] = currCAN.byte3;
  canMsg.data[3] = currCAN.byte4;
  canMsg.data[4] = currCAN.byte5;
  canMsg.data[5] = currCAN.byte6;
  canMsg.data[6] = currCAN.byte7;
  canMsg.data[7] = currCAN.byte8;
  
  /* Old way of structuring CAN Data
  //indicating data is coming from the current sensor
  //First data byte doesn't need to be ID anymore!!
  canMsg.data[0] = 0;
  canMsg.data[1] = currentArr.arr[0];
  canMsg.data[2] = currentArr.arr[1];
  canMsg.data[3] = currentArr.arr[2];
  canMsg.data[4] = currentArr.arr[3];
  canMsg.data[5] = currentArr.arr[4];
  canMsg.data[6] = currentArr.arr[5];
  canMsg.data[7] = currentArr.arr[6];
  //NEW: EX data: 0|c1|c2|c3|c4|c5|c6|c7
  */

  if(debug)
  {
    Serial.print("Sent Current 1 with: ");
    Serial.println(current);
  }

  if(mcp2515.sendMessage(&canMsg) == 0) //Sends the CAN message
    return true;  //if successful
  else
    return false; //if failed 
}

//function description here
float SensorFunctions::calibrateCurr(int currPin)
{
  Serial.println("Starting Current Sensor Calibration!");
  Serial.println("Make sure that nothing is plugged into the sensor!\n\n");
  delay(500);
  Serial.println("Starting in 3 seconds\n");
  delay(3000);
  float rawReading = 0.0;
  delay(100); //wait 100ms before collecting data
  Serial.println("Collecting readings!\n\n");
  for(int i = 0; i < 150; i++)
  {
    rawReading += analogRead(currPin);
    delay(3);
  }
  float offset = rawReading / 150;
  Serial.println("Calibration done!");
  Serial.print("Calibrated Reading for Zero current (Current Sensor @ Pin #");
  Serial.print(currPin);
  Serial.print(" ): ");
  Serial.println(offset);
  return offset;
}

// transmitGPS w
bool SensorFunctions::transmitGPS(MCP2515 mcp2515, Adafruit_GPS GPS, struct can_frame canMsg, canid_t id, bool debug)
{
  canMsg.can_id  = id;
  canMsg.can_dlc = 8;  //CAN data array length

  //fetch data from the GPS
  if(GPS.fix)
  {
    Serial.print("Location: ");
    //Put the lat and long into a CanFloats:
    CanFloats gpsData = CanFloats(ToDecimalDegrees(GPS.latitude, GPS.lat), ToDecimalDegrees(GPS.longitude, GPS.lon));

    //now store them in a floatPair which holds 2 float values
    floatPair gpsFloats = gpsData.getFloats();
    

    //Parse them into a CAN format which breaks down the 2 32bit numbers into 8 bytes
    CAN gpsCAN = gpsData.getCAN();

    //Now send over the data byte by byte:
    canMsg.data[0] = gpsCAN.byte1;
    canMsg.data[1] = gpsCAN.byte2;
    canMsg.data[2] = gpsCAN.byte3;
    canMsg.data[3] = gpsCAN.byte4;
    canMsg.data[4] = gpsCAN.byte5;
    canMsg.data[5] = gpsCAN.byte6;
    canMsg.data[6] = gpsCAN.byte7;
    canMsg.data[7] = gpsCAN.byte8;

    if(debug)
    {
      //print out the decimal degrees recieved from the GPS
      Serial.print("Sent GPS Data: ");
      Serial.print(gpsFloats.num1, 4);
      Serial.print(", ");
      Serial.println(gpsFloats.num2, 4);
    }

    if(mcp2515.sendMessage(&canMsg) == 0) //Sends the CAN message
        return true;  //if successful
      else
        return false; //if failed 
  }
  else
  {
    //if the GPS was not able to get a fix, give a warning
    Serial.print("GPS does not have a fix!\t");
    return false; //if failed 
  }
}

// this function will setup the GPS by taking the serial port of where the GPS is connected to and returns
// an Adafruit_GPS object that will be used in the transmitGPS function
Adafruit_GPS SensorFunctions::gpsSetup(HardwareSerial *serialPtr)
{
  Adafruit_GPS GPS(serialPtr);
  
  //GPS setup:
  GPS.begin(9600);
  GPS.sendCommand(PMTK_SET_NMEA_OUTPUT_RMCGGA);
  GPS.sendCommand(PMTK_SET_NMEA_UPDATE_1HZ);
  GPS.sendCommand(PGCMD_ANTENNA);
  delay(1000);
  return GPS;
}

/*
******************************************************************************************************************
Public Receive Functions:
******************************************************************************************************************
*/

//code to translate accelerometer CAN data into x,y,z values
//Needs to return 3 floats, with only 1 decimal point precision
//returns a accelDataArr, 3 indexes, 1 for each float
accelDataArr SensorFunctions::parseAccel(can_frame msg, bool debug)
{
  float x = canToOneFloat(msg.data, 1, 2);
  float y = canToOneFloat(msg.data, 3, 4);
  float z = canToOneFloat(msg.data, 5, 6);

  accelDataArr output = {x, y, z};

  if(debug)
  {
    Serial.print("Accel Sensor ID: ");
    Serial.print(msg.can_id, HEX);

    //printing out X axis values:
    Serial.print("\tX: ");
    Serial.print(x, 1);

    //printing out Y axis values:
    Serial.print("\tY: ");
    Serial.print(y, 1);

    //printing out Z axis values:
    Serial.print("\tZ: ");
    Serial.println(z, 1);
  }
  return output;
}

//converts a can message to a float that represents the current sensor data
float SensorFunctions::parseCurrent(can_frame msg, bool debug)
{
  //convert data to a CAN struct:
  struct CAN can;
  can.byte1 = msg.data[0];
  can.byte2 = msg.data[1];
  can.byte3 = msg.data[2];
  can.byte4 = msg.data[3];
  can.byte5 = msg.data[4];
  can.byte6 = msg.data[5];
  can.byte7 = msg.data[6];
  can.byte8 = msg.data[7];

  CanFloats canfloats = CanFloats();

  //called currNull since first byte has data but second byte should be 0
  floatPair currNull = canfloats.canToFloats(can);
  float current = currNull.num1;
  if(debug)
  {
    Serial.print("Current Sensor ID: ");
    Serial.print(msg.can_id, HEX);

    //Printing out the current values:
    Serial.print("\t");
    Serial.print(current, 6);
    Serial.println("A");
  }
  return current;
}

//converts a can message to a floatPair containing the lat long for GPS.
//Will probably have to rename it since it only handles latlong, other data might
//want to be pulled such as the speed, fix, and other GPS related data
floatPair SensorFunctions::parseGPS(can_frame msg, bool debug)
{
  //convert data to a CAN struct:
  struct CAN can;
  can.byte1 = msg.data[0];
  can.byte2 = msg.data[1];
  can.byte3 = msg.data[2];
  can.byte4 = msg.data[3];
  can.byte5 = msg.data[4];
  can.byte6 = msg.data[5];
  can.byte7 = msg.data[6];
  can.byte8 = msg.data[7];

  CanFloats canfloats = CanFloats();
  floatPair latLong = canfloats.canToFloats(can);

  if(debug)
  {
    Serial.print("Lat: ");
    Serial.print(latLong.num1, 4);
    Serial.print(" Long: ");
    Serial.println(latLong.num2, 4);
  }

  return latLong;
}